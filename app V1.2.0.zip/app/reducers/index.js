import ValEdu from './ValEdu'

export { ValEdu }
