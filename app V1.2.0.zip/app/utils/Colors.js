export default {
  title: 'rgb(255, 255, 255)',
  moreStory: 'rgb(153, 153, 102)',
  white: 'rgb(255, 255, 255)',
  textColor: 'rgb(0, 0, 0)',
}
