import React from 'react'
import { connect } from 'react-redux'
import ValueEducation from '../components/Main'

function ValEduApp(props) {
  // alert(props.selectedImages)
  return <ValueEducation />
}

function mapStateToProps(state) {
  return {
    selectedImages: state.ValEdu.get('selectedImages'),
  }
}

export default connect(mapStateToProps)(ValEduApp)
