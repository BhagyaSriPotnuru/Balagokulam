import React, { Component, PropTypes } from 'react'
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  ScrollView,
  StatusBar,
  NetInfo,
  Alert,
  AsyncStorage,
} from 'react-native'
import { Actions } from 'react-native-router-flux'
import dismissKeyboard from 'react-native-dismiss-keyboard'
import styles from '../../utils/Styles'
import http from '../../utils/Http'

let DeviceInfo = require('react-native-device-info')
let model = DeviceInfo.getModel()
let token
let userId

export default class CodeVerify extends Component {
  constructor(props) {
    super(props)
    this.state = { code: null }
  }
  componentDidMount = () => {
    this.refs.code.focus()
  }
  verifyCode = async () => {
    dismissKeyboard()
    if (this.props.otp == this.state.code) {
      if (this.props.isRegistered) {
        try {
          await AsyncStorage.setItem('token', this.props.token)
          await AsyncStorage.setItem('refreshToken', this.props.refreshToken)
          await AsyncStorage.setItem('userId', this.props.userId)
        } catch (e) { }

        if (this.props.token) {
          NetInfo.fetch().done((reach) => {
            if (reach === 'none') {
              Alert.alert (
              'Balagokulam - Seekho Sikhao',
              'Please connect to internet for accessing the app',
              [
                { text: 'OK'},
              ]
            )
            } else {
              this.getProfileInfo()
            }
          })
        }
      } else {
        Actions.profileinfo({ phoneNumber: this.props.phoneNumber,navigationBarStyle : {backgroundColor: 'rgb(182, 73, 38)'} })
      }
    } else {
      Alert.alert(
        '',
        'OTP does not match',
        [
          { text: 'OK', onPress: () => { this.refs.code.focus(); } },
        ],
        { cancellable: false }
      )
    }
  }

  getProfileInfo = async () => {
    try {
      dismissKeyboard()
      token = await AsyncStorage.getItem('token')
      userId = await AsyncStorage.getItem('userId') 
      http('profileInfo', { userId }, 'POST', token)
      .then(async (response) => {
        if (response.status) {
            await AsyncStorage.setItem('name', response.name)
            await AsyncStorage.setItem('email', response.email)
            await AsyncStorage.setItem('profileImage', response.profileImage)
            await AsyncStorage.setItem('phoneNumber', this.props.phoneNumber)
            await AsyncStorage.setItem('dbUpdated', 'true')
          this.saveVersion()
          Actions.drawer()
        } else {
          // alert(response.Message)
        }
      })
      .catch((error) => {
        // alert(error)
      })
    } catch (e) {}
  }

  saveVersion = async () => {   
    try {
      token = await AsyncStorage.getItem('token')
      userId = await AsyncStorage.getItem('userId')     
      http('saveUserVersion', { userId, version: DeviceInfo.getVersion(), devicePlatform: Platform.OS }, 'POST', token)
      .then((response) => {
        if (response.status) {
        } 
      })
      .catch((error) => {
        // alert(error)
      })
    } catch (e) {}
  }

  render() {
    return (
      <View style={[styles.container, {flex: 1,
          backgroundColor: 'rgb(255, 240, 165)'}]}>
      <StatusBar
          backgroundColor="rgb(168, 69, 36)"
          barStyle="light-content"
        />
        <ScrollView showsVerticalScrollIndicator={false}
          keyboardShouldPersistTaps={true}>
          <Text style={styles.textColor}>Verification code has been sent through SMS to {this.props.phoneNumber}.
            <Text
              onPress={() => Actions.pop()}
              style={[styles.textColor, { color: "rgb(224, 110, 56)" }]}
            > Wrong Number?</Text>
          </Text>
          <Text style={[styles.textColor, { marginVertical: 15 }]}>
          Please enter 6 digit verification code.</Text>
          <View style={styles.textInput}> 
          <TextInput
            ref="code"
            style={{ height: 40, fontSize: model.includes('iPhone 5') || model.includes('iPhone 4') ? 12 : 14 }}   
            onChangeText={(code) => this.setState({ code })}
            placeholder=""
            value={this.state.code}
            keyboardType="numeric"
            maxLength={6}
            returnKeyType="done"
          />
          </View>
          <TouchableOpacity
            onPress={this.verifyCode}
            style={[styles.loginbutton, { backgroundColor: "rgb(224, 110, 56)" }]}
          >
            <Text style={styles.buttonText}>Next</Text>
          </TouchableOpacity>
        </ScrollView>
      </View>
    )
  }
}

CodeVerify.propTypes = {
  phoneNumber: PropTypes.number,
  otp: PropTypes.string,
  isRegistered: PropTypes.bool,
  token: PropTypes.string,
  refreshToken: PropTypes.string,
  userId: PropTypes.string, 
}