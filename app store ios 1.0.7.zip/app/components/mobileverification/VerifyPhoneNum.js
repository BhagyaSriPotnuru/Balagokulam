import React, { Component, PropTypes } from 'react'
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  Alert,
  ScrollView,
  NetInfo,
  Image,
  Dimensions,
  StatusBar,
  AsyncStorage,
  Platform,
} from 'react-native'
import { Actions } from 'react-native-router-flux'
import dismissKeyboard from 'react-native-dismiss-keyboard'
import { connect } from 'react-redux'
import Orientation from 'react-native-orientation'
import styles from '../../utils/Styles'
import { validatePhoneNumber } from '../../utils/Validations'
import http from '../../utils/Http'
import Colors from '../../utils/Colors'
import Footer from '../Footer'
import PhoneNumberPicker from 'react-native-country-code-telephone-input'
let DeviceInfo = require('react-native-device-info')

const width = Dimensions.get('window').width
const height = Dimensions.get('window').height

export default class VerifyPhoneNum extends Component {

  constructor(props) {
    super(props)
    this.state = { phoneNumber: ''}
  }

  getCode = () => {
    dismissKeyboard()
    const phoneNumber = this.state.phoneNumber
    const phoneError = validatePhoneNumber(phoneNumber)
    if (phoneNumber && !phoneError) {
      Alert.alert(
        'We will be verifying the phone number: +91- ' + this.state.phoneNumber,
        'Is this OK, or would you like to edit the number?',
        [
          { text: 'EDIT', onPress: () => { this.refs['1'].focus(); } },
          { text: 'OK', onPress: this.verifyPhone },
        ],
        { cancelable: false }
      )
    }
    if (phoneNumber && phoneError) {
      Alert.alert(
        '',
        'Please enter a valid phone number',
        [
          { text: 'OK', onPress: () => { this.refs['1'].focus(); } },
        ],
        { cancelable: false }
      )
    }
    if (!phoneNumber) {
      Alert.alert(
        '',
        'Please enter a valid phone number',
        [
          { text: 'OK', onPress: () => { this.refs['1'].focus(); } },
        ],
        { cancelable: false }
      )
    }
  }

  PhoneNumberPickerChanged = async (country, callingCode, phoneNumber) => {
    let phoneError = validatePhoneNumber(phoneNumber)
    const num = '+' + callingCode + '-' + phoneNumber
    this.setState({phoneNumber: callingCode + phoneNumber, phoneError})

    if(phoneNumber.length == 10) {
      dismissKeyboard()           
      await AsyncStorage.setItem('phoneNumber', num)
      // this.verifyPhone()
    }
  }

  verifyPhone = () => {
    NetInfo.fetch().done((reach) => {
      if (reach === 'none') {
        Alert.alert(
        'Balagokulam - Seekho Sikhao',
        'Please connect to internet for accessing the app',
        [
          { text: 'OK'},
        ]
      )
      } else {
        const data = {
          phoneNumber: '91'+this.state.phoneNumber,
          devicePlatform: Platform.OS,
        }
        const data1 = {
          phoneNumber: '91'+this.state.phoneNumber,
          deviceUdId: DeviceInfo.getUniqueID(),
        }
        http('sendotp', data).then((response) => {
          if (response.status) {            
            const phoneNumber = this.state.phoneNumber
            const isRegistered = response.isAlreadyRegistered
            const otp = response.otp
            // alert(otp)
            if (response.isAlreadyRegistered && !response.isActive) {
              Alert.alert(
                'An account with this number already exists',
                'Do you want to reactivate your account?',
                [
                  { text: 'CANCEL' },
                  { text: 'OK', onPress: () => {
                    http('reactivateAccount', data1).then((result) => {
                      if (result.status) {
                        // alert(JSON.stringify(response))
                        Actions.codeverify({
                          phoneNumber,
                          otp,
                          isRegistered,
                          token: result.loginResponse.access_token,
                          refreshToken: result.loginResponse.refresh_token,
                          userId: result.loginResponse.userId,
                          navigationBarStyle : {backgroundColor: 'rgb(182, 73, 38)'},
                        })
                      }
                    })
                    .catch((error) => {
                      // alert(error)
                    })
                  } },
                ],
                { cancelable: false }
              )
            } else if (response.isAlreadyRegistered && response.isActive) {
              Actions.codeverify({
                phoneNumber,
                otp,
                isRegistered: response.isAlreadyRegistered,
                token: response.loginResponse.access_token,
                refreshToken: response.loginResponse.refresh_token,
                userId: response.loginResponse.userId,
                navigationBarStyle : {backgroundColor: 'rgb(182, 73, 38)'},
              })
            } else {
              Actions.codeverify({
                phoneNumber,
                otp,
                isRegistered: response.isAlreadyRegistered,
                navigationBarStyle : {backgroundColor: 'rgb(182, 73, 38)'},
              })
            }
          } else {
            // alert(JSON.stringify(response))
          }
        })
        .catch((error) => {
          // alert(error)
        })     
      }
    })
  }

  phoneNumOnChange = (event) => {
    const phoneNumber = event.nativeEvent.text
    this.setState({ phoneNumber })
  }

  render() {
    return (
      <View style={[styles.container, {flex: 1,
          backgroundColor: 'rgb(255, 240, 165)'}]}>
        <StatusBar
          backgroundColor="rgb(168, 69, 36)"
          barStyle="light-content"
        />
        <ScrollView
          showsVerticalScrollIndicator={false}
          keyboardShouldPersistTaps={true}>
          <Text style={styles.textColor}>
            Balagokulam will send an SMS to verify your mobile number.
            Please enter your 10 digit mobile number.
          </Text>
          <View style={styles.textInput}>                              
          <TextInput
            ref="1"
            style={styles.phoneNumber}
            onChange={this.phoneNumOnChange}
            placeholder="Mobile number"
            value={this.state.phoneNumber}
            keyboardType="phone-pad"
            maxLength={10}
            autoFocus={true}
            returnKeyType="go"
            onSubmitEditing={this.getCode}
            clearButtonMode="while-editing"
          />
          </View>
          <TouchableOpacity
            onPress={this.getCode}
            style={[styles.loginbutton, { backgroundColor: 'rgb(224, 110, 56)' }]}
          >
            <Text style={styles.buttonText}>Next</Text>
          </TouchableOpacity>
        </ScrollView>
        <Footer />
      </View>
    )
  }
}

// <View style={[styles.textInput, { flex: 1 }]}>
//             <PhoneNumberPicker
//               countryHint={{ name: 'India', cca2: 'IN', callingCode: '91' }}
//               onChange={this.PhoneNumberPickerChanged}
//             />         
//           </View>

 
