import React, { Component, PropTypes } from 'react'
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  ScrollView,
  Alert,
  NetInfo,
  AsyncStorage,
  Image,
  Dimensions,
  StatusBar,
  Platform,
} from 'react-native'
import { Actions } from 'react-native-router-flux'
import dismissKeyboard from 'react-native-dismiss-keyboard'
import Orientation from 'react-native-orientation'
import styles from '../../utils/Styles'
import http from '../../utils/Http'
import Colors from '../../utils/Colors'
import Footer from '../Footer'

const width = Dimensions.get('window').width
const height = Dimensions.get('window').height

let DeviceInfo = require('react-native-device-info')
let model = DeviceInfo.getModel()

export default class CodeVerify extends Component {

  constructor(props) {
    super(props)
    this.state = {
      code1: '',
      code2: '',
      code3: '',
      code4: '',
      code5: '',
      code6: '',
      keyPressed: null,
    }
  }

  changeCode1 = (event) => {
    const code1 = event.nativeEvent.text
    this.setState({ code1 })
    if(code1 != '')
    this.refs.code2.focus()
  }

  changeCode2 = (event) => {
    const code2 = event.nativeEvent.text
    this.setState({ code2 })
    if(code2 != '')
      this.refs.code3.focus()
    else
      this.refs.code1.focus()
  }

  changeCode3 = (event) => {
    const code3 = event.nativeEvent.text
    this.setState({ code3 })
    if(code3 != '')
      this.refs.code4.focus()
    else
      this.refs.code2.focus()
  }

  changeCode4 = (event) => {
    const code4 = event.nativeEvent.text
    this.setState({ code4 })
    if(code4 != '')
      this.refs.code5.focus()
    else
      this.refs.code3.focus()
  }

  changeCode5 = (event) => {
    const code5 = event.nativeEvent.text
    this.setState({ code5 })
    if(code5 != '')
      this.refs.code6.focus()
    else
      this.refs.code4.focus()
  }

  changeCode6 = (event) => {
    const code6 = event.nativeEvent.text
    this.setState({ code6 })
    if(code6 == '')
      this.refs.code5.focus()
  }

  verifyCode = async () => {
    let otp = this.state.code1 + this.state.code2 +this.state.code3 +this.state.code4 +this.state.code5 +this.state.code6
    dismissKeyboard()
    if (this.props.otp == otp) {
      if (this.props.isRegistered) {
        try {
          await AsyncStorage.setItem('token', this.props.token)
          await AsyncStorage.setItem('refreshToken', this.props.refreshToken)
          await AsyncStorage.setItem('userId', this.props.userId)
        } catch (e) { }

        if (this.props.token) {
          NetInfo.fetch().done((reach) => {
            if (reach === 'none') {
              Alert.alert (
              'Balagokulam - Seekho Sikhao',
              'Please connect to internet for accessing the app',
              [
                { text: 'OK'},
              ]
            )
            } else {
              http('profileInfo', { userId: this.props.userId }, 'POST', this.props.token)
              .then(async (response) => {
                if (response.status) {
                  try {
                    await AsyncStorage.setItem('name', response.name)
                    await AsyncStorage.setItem('email', response.email)
                    await AsyncStorage.setItem('profileImage', response.profileImage)
                    await AsyncStorage.setItem('phoneNumber', this.props.phoneNumber)
                  } catch (e) {}
                  Actions.drawer()
                } else {
                  // alert(response.Message)
                }
              })
              .catch((error) => {
                // alert(error)
              })
            }
          })
        }
      } else {
        Actions.profileinfo({ phoneNumber: this.props.phoneNumber,navigationBarStyle : {backgroundColor: 'rgb(182, 73, 38)'} })
      }
    } else {
      Alert.alert(
        '',
        'OTP does not match',
        [
          { text: 'OK', onPress: () => { this.refs.code6.focus(); } },
        ],
        { cancellable: false }
      )
    }
  }

  render() {
    return (
      <View style={[styles.container, {flex: 1,
          backgroundColor: 'rgb(255, 240, 165)'}]}>
      <StatusBar
          backgroundColor="rgb(168, 69, 36)"
          barStyle="light-content"
        />
        <ScrollView
          showsVerticalScrollIndicator={false}
          keyboardDismissMode="on-drag"
          keyboardShouldPersistTaps={true}
        >
          <Text style={styles.textColor}>Verification code has been sent through SMS to +91- {this.props.phoneNumber}.
            <Text
              onPress={() => Actions.pop()}
              style={[styles.textColor, { color: "rgb(224, 110, 56)" }]}
            > Wrong Number?</Text>
          </Text>
          <Text style={[styles.textColor, { marginVertical: 15 }]}>
          Please enter 6 digit verification code.</Text>
        <View style={[styles.spaceContainer,{flex: 1}]}>
          <View style={[styles.textInput,{flex:0.1}]}> 
          <TextInput
            ref="code1"
            onChange={this.changeCode1}
            style={{ height: 40, fontSize: model.includes('iPhone 5') || model.includes('iPhone 4') ? 12 : 14 }}           
            value={this.state.code1}
            keyboardType="numeric"
            maxLength={1}
            returnKeyType="next"
            autoFocus={true}
            controlled={true}
            textAlign="center"
            onSubmitEditing={(e) => this.refs.code2.focus()}
          />
          </View>
          <View style={[styles.textInput,{flex:0.1}]}> 
          <TextInput
            ref="code2"
            onChange={this.changeCode2}
            style={{ height: 40, fontSize: model.includes('iPhone 5') || model.includes('iPhone 4') ? 12 : 14 }}
            value={this.state.code2}
            keyboardType="numeric"
            maxLength={1}
            returnKeyType="next"
            textAlign="center"
            controlled={true}
            onSubmitEditing={(e) => this.refs.code3.focus()}
          />
          </View>
          <View style={[styles.textInput,{flex:0.1}]}> 
          <TextInput
            ref="code3"
            onChange={this.changeCode3}
            style={{ height: 40, fontSize: model.includes('iPhone 5') || model.includes('iPhone 4') ? 12 : 14 }}
            value={this.state.code3}
            keyboardType="numeric"
            maxLength={1}
            returnKeyType="next"
            textAlign="center"
            controlled={true}
            onSubmitEditing={(e) => this.refs.code4.focus()}
          />
          </View>
          <View style={[styles.textInput,{flex:0.1}]}> 
          <TextInput
            ref="code4"
            onChange={this.changeCode4}
            style={{ height: 40, fontSize: model.includes('iPhone 5') || model.includes('iPhone 4') ? 12 : 14 }}
            value={this.state.code4}
            keyboardType="numeric"
            maxLength={1}
            returnKeyType="next"
            textAlign="center"
            controlled={true}
            onSubmitEditing={(e) => this.refs.code5.focus()}
          />
          </View>
          <View style={[styles.textInput,{flex:0.1}]}> 
          <TextInput
            ref="code5"
            onChange={this.changeCode5}
            style={{ height: 40, fontSize: model.includes('iPhone 5') || model.includes('iPhone 4') ? 12 : 14 }}
            value={this.state.code5}
            keyboardType="numeric"
            maxLength={1}
            returnKeyType="next"
            textAlign="center"
            controlled={true}
            onSubmitEditing={(e) => this.refs.code6.focus()}
          />
          </View>
          <View style={[styles.textInput,{flex:0.1}]}> 
          <TextInput
            ref="code6"
            onChange={this.changeCode6}
            style={{ height: 40, fontSize: model.includes('iPhone 5') || model.includes('iPhone 4') ? 12 : 14 }}
            value={this.state.code6}
            keyboardType="numeric"
            maxLength={1}
            returnKeyType="go"
            textAlign="center"
            controlled={true}
            onSubmitEditing={this.verifyCode}
          />
          </View>
          </View>
          <TouchableOpacity
            onPress={this.verifyCode}
            style={[styles.loginbutton, { backgroundColor: "rgb(224, 110, 56)" }]}
          >
            <Text style={styles.buttonText}>Next</Text>
          </TouchableOpacity>
        </ScrollView>
      <Footer />
      </View>
    )
  }
}

CodeVerify.propTypes = {
  phoneNumber: PropTypes.number,
  otp: PropTypes.string,
  isRegistered: PropTypes.bool,
  token: PropTypes.string,
  refreshToken: PropTypes.string,
  userId: PropTypes.string, 
}
