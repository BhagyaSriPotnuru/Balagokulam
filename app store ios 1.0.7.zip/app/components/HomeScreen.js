import React, { Component, PropTypes } from 'react'
import {
  View,
  ListView,
  AsyncStorage,
  Text,
  TouchableOpacity,
  TextInput,
  StatusBar,
  Image,
  NetInfo,
  Platform,
  Animated,
  Easing,
  Alert,
} from 'react-native'
import Spinner from 'react-native-loading-spinner-overlay'
import { Actions } from 'react-native-router-flux'
import Icon from 'react-native-vector-icons/FontAwesome'
import dismissKeyboard from 'react-native-dismiss-keyboard'
import { connect } from 'react-redux'
import Footer from './Footer'
import GoogleAnalytics from 'react-native-google-analytics-bridge'
import { getRefreshToken } from './refreshToken'
import DeviceInfo from 'react-native-device-info'
import SQLite from 'react-native-sqlite-storage'
import noImageIcon from '../images/noImage.png'
import  insertData from '../utils/InsertRecords'
import {
  startSpinner,
  stopSpinner,
  records,
  dateChange,
  onNotify,
  isCalendar,
  channelChange,
} from '../actions/ValEduActions'
import http from '../utils/Http'
import styles from '../utils/Styles'
import Colors from '../utils/Colors'

const PushNotification = require('react-native-push-notification')
const ds = new ListView.DataSource({ rowHasChanged: (r1, r2) => r1 !== r2 });
let index = 0
let width
let registerToken
let token
let userId
let statusText = ''
let recordLength
let listViewscroll = true
let noInternetAlertTriggered =false
let isCacheCreated
let cacheRecordsNum = 0
let currentDate
let db
let recordsRendered = true

class HomeScreen extends Component {
  constructor(props) {
    super(props)
    this.state = {
      rows: [],
      tag: '',
      isRecords: true,
      search: false,
      recordsExist: true,
      reach: 'none',
      rowsDisplayed : -1,
    }
    this.animatedValue = new Animated.Value(0)
    db = SQLite.openDatabase({
      name: 'test.db',
      createFromLocation : "~balagokulam.db",
      location: 'Library'
    }, () => {
    // console.log('db opened')
      }, (e) => { // console.log('error' + JSON.stringify(e))
    })
  }

  componentDidMount = async () => {
    try {
      dbCreated = await AsyncStorage.getItem('dbCreated')
      dbCreated = JSON.parse(dbCreated)
      this.animate()
      NetInfo.fetch().done((reach) => {
        this.setState({reach})
        if(reach !== 'none') {  
          this.setState({recordsExist: true})
          noInternetAlertTriggered = false
        }
      })
      NetInfo.addEventListener('change',this.handleConnectionInfoChange)
      const { dispatch } = this.props
      dispatch(startSpinner())
      this.getContent()
      if(this.props.notify || this.props.isChannelChanged) {
        dispatch(onNotify(false))
        dispatch(channelChange(false))
        cacheRecordsNum = 0                    
        this.setState({rowsDisplayed : -1, rows: [], recordsExist: true})
        setTimeout(()=>this.getContent(), 0)
      }
      setInterval(() => {
        if(this.props.notify || this.props.isChannelChanged) {
          dispatch(onNotify(false))
          dispatch(channelChange(false))
          cacheRecordsNum = 0           
          this.setState({rowsDisplayed: -1, rows: [], recordsExist: true})
          setTimeout(()=>this.getContent(), 0)
        }
      }, 1500)
    } catch(e) {}
  }

  handleConnectionInfoChange = (reach) => {
    this.setState({reach})
    if(reach !== 'none') {  
      this.setState({recordsExist: true})
      noInternetAlertTriggered = false
    }
  }

  componentWillUnmount() {
    NetInfo.removeEventListener('change', this.handleConnectionInfoChange)
  }

  animate = () => {
    this.animatedValue.setValue(0)
    Animated.timing(
      this.animatedValue,
      {
        toValue: 1,
        duration: 3000,
        easing: Easing.linear
      }
    ).start(() => this.animate())
  }

  getListViewData = () => {
    let dataList = []
    const { rows } = this.props
    rows.map(row => {
      let rowData = {}
      rowData.title = row.get('title')
      rowData.imageUrl = row.get('imageUrl')
      rowData.story = row.get('story')
      rowData.thought = row.get('thought')
      rowData.createdOn = row.get('createdOn')
      rowData.tId = row.get('tId')
      dataList.push(rowData)
    })
    recordLength = dataList.length
    return dataList
  }

  displayContent = async () => {
    // alert(cacheRecordsNum + ' displayContent ' + this.state.rowsDisplayed)
    recordsRendered = false
    try {
      token = await AsyncStorage.getItem('token')
      userId = await AsyncStorage.getItem('userId')
      isCacheCreated = await AsyncStorage.getItem('cacheCreated')
      isCacheCreated = JSON.parse(isCacheCreated)
    }
    catch(e) {}    
    const { dispatch } = this.props
    let recordsList = []
    if (!isCacheCreated || this.state.rowsDisplayed >= cacheRecordsNum || cacheRecordsNum == 0) {
      if (this.state.reach === 'none') {
          noInternetAlertTriggered = true
          recordsRendered = true
          this.setState({recordsExist: false})
          dispatch(stopSpinner())
          Alert.alert(
            'Balagokulam - Seekho Sikhao',
            'You are offline. Please Connect to internet to view more Stories',
            [
              { text: 'OK'},
            ]
          )
      } else {
        noInternetAlertTriggered = false
        http('fetchNextRecords', { currentCount: this.state.rowsDisplayed, type: 'all', userId }, 'POST', token)
        .then((response) => {          
          if (response.Message) {
            getRefreshToken()
            this.displayContent()
          } else if (!response.isActive) {
            AsyncStorage.multiRemove(['theme', 'dbUpdated', 'token', 'registerToken', 'refreshToken', 'name', 'email', 'profileImage', 'phoneNumber'])
            Actions.welcome()            
          } else if (response.status && response.recordList) {
            // alert(response.recordList.length)
            this.setState({rowsDisplayed : this.state.rowsDisplayed + response.recordList.length})
            if(response.recordList.length < 10) {
              this.setState({recordsExist: false})
            } else {
               this.setState({recordsExist: true})
            }
            this.setState({ rows: this.state.rows.concat(response.recordList) })
            dispatch(records(this.state.rows))
            dispatch(stopSpinner())
            recordsRendered = true        
          } 
          if (response.status && !response.recordList) {
            this.setState({recordsExist: false})
            recordsRendered = true
          }
        })
        .catch((error) => {
          // alert('error')
        })
      }

    } else if (isCacheCreated && this.state.rowsDisplayed < cacheRecordsNum) {
      let query = 'select rtd.record_title_id as tId,rtd.title as title,rtd.createdOn,story,thought,image as imageUrl '+
        'from (select * from record_title_data '+
        'where date(createdOn)<=\'' + currentDate + '\' order by date(createdOn) desc,record_title_id desc limit 10 offset ?) as rtd '+
        'inner join record_data on record_data.record_id=rtd.record_title_id'
      db.transaction((tx) => {
        tx.executeSql(query, [this.state.rowsDisplayed], (tx, results) => {
          // alert(results.rows.length)
          if (results.rows.length > 0) {
             for (let index = 0; index < results.rows.length; index++) {
                let row = results.rows.item(index)
                recordsList.push(row)
             }
             this.setState({ rows: this.state.rows.concat(recordsList) })
             recordsRendered = true
             dispatch(records(this.state.rows))
             dispatch(stopSpinner())
             this.setState({rowsDisplayed: this.state.rowsDisplayed === -1 ? 0 : this.state.rowsDisplayed})
             this.setState({rowsDisplayed : this.state.rowsDisplayed + results.rows.length})
             if(results.rows.length < 10) {
                this.getNextRecords()
             }
          }
        },(e) => {
          // console.log('error' + JSON.stringify(e))
      })
     })           
    }
  }


  getContent = async () => {
    currentDate = JSON.stringify(new Date())
    currentDate = currentDate.substring(1,11)
    try {
      isCacheCreated = await AsyncStorage.getItem('cacheCreated')
      isCacheCreated = JSON.parse(isCacheCreated)
    } catch(e) {}
    // alert(isCacheCreated)
    if(isCacheCreated) {
      if (this.state.rowsDisplayed === -1) {
        db.transaction((tx) => {
          tx.executeSql('select count(*) as count from record_title_data where date(createdOn) = \'' + currentDate + '\'', [], (tx, data) => {
            if (data.rows.item(0).count == 0) {
              tx.executeSql('select min(createdOn) as createdOn from record_title_data where date(createdOn) > \'' + currentDate + '\'',
              [], (tx, results) => {
                if(results.rows.item(0).createdOn) {
                  currentDate = JSON.stringify(new Date(results.rows.item(0).createdOn))
                  currentDate = currentDate.substring(1,11)
                }
                tx.executeSql('select count(*) as count from record_title_data where date(createdOn) <= \'' + currentDate + '\'',
                [], (tx, results) => {
                  cacheRecordsNum = results.rows.item(0).count
                  this.displayContent()
                }, (e) => {
                // console.log('error' + JSON.stringify(e))
              }) 
              }, (e) => {
              // console.log('error' + JSON.stringify(e))
            })
            } else {
              tx.executeSql('select count(*) as count from record_title_data where date(createdOn) <= \'' + currentDate + '\'',
              [], (tx, results) => {
                cacheRecordsNum = results.rows.item(0).count
                this.displayContent()
              }, (e) => {
              // console.log('error' + JSON.stringify(e))
            }) 
            }
          },(e) => {
          // console.log('error' + JSON.stringify(e))
        })
        })
      }
    } else {
      this.displayContent()
    }
  }

  getNextRecords = () => {
    listViewscroll = this.refs.listview.scrollProperties.offset +
      this.refs.listview.scrollProperties.visibleLength >=
      this.refs.listview.scrollProperties.contentLength
    if ((listViewscroll || this.state.rowsDisplayed < 10) && recordsRendered && this.state.recordsExist && !this.state.search && !noInternetAlertTriggered) {
      this.displayContent()
    }
  }

  searchRecords = async () => {
    try {
      token = await AsyncStorage.getItem('token')
      userId = await AsyncStorage.getItem('userId')
    }
    catch (e) {}
    const { dispatch } = this.props
    if (this.state.reach === 'none') {
      Alert.alert(
        'Balagokulam - Seekho Sikhao',
        'You are offline. Please connect to internet',
        [
          { text: 'OK'},
        ]
      )
    } else {
      http('searchRecords', { searchkey: this.state.tag, type: 'all', userId }, 'POST', token)
      .then((response) => {
        if(response.Message) {
          getRefreshToken()
          this.searchRecords()
        } else if (!response.isActive) {
          AsyncStorage.multiRemove(['theme', 'dbUpdated', 'token', 'registerToken', 'refreshToken', 'name', 'email', 'profileImage', 'phoneNumber'])
          Actions.welcome()
        } else if (response.status && response.searchList) {
          this.setState({ isRecords: true })
          dispatch(records(response.searchList))         
        } else {
          this.setState({ isRecords: false })
        }
      })
      .catch((error) => {
        // alert(error)
      })
    }
  }

  search = () => {
    dismissKeyboard()
    if (this.state.tag) {
      this.searchRecords()
    } else {
      const { dispatch } = this.props
      dispatch(records(this.state.rows))
    }
  }

  onChangeTag = (tag) => {
    this.setState({ tag })
    let newRows = []
    let row = 0
    const data = this.state.rows
    for (row = 0; row < data.length; row++) {
      let thoughtSearchkey = data[row].thoughtSearchkey
      let storySearchkey = data[row].storySearchkey
      let imageSearchkey = data[row].imageSearchkey
      let videoSearchkey = data[row].videoSearchkey
      if (!thoughtSearchkey) {
        thoughtSearchkey = ''
      }
      if (!storySearchkey) {
        storySearchkey = ''
      }
      if (!imageSearchkey) {
        imageSearchkey = ''
      }
      if (!videoSearchkey) {
        videoSearchkey = ''
      }
      if (thoughtSearchkey.toLowerCase().indexOf(tag.toLowerCase()) !== -1
        || storySearchkey.toLowerCase().indexOf(tag.toLowerCase()) !== -1
        || imageSearchkey.toLowerCase().indexOf(tag.toLowerCase()) !== -1
        || videoSearchkey.toLowerCase().indexOf(tag.toLowerCase()) !== -1) {
        newRows.push(data[row])
      }
    }
    if (newRows) {
      this.setState({ isRecords: true })
      const { dispatch } = this.props
      dispatch(records(newRows))
    } else {
      this.setState({ isRecords: false })
    }
  }

  renderRowElement = (rowData, sectionID, rowID) => {
    const introButton = this.animatedValue.interpolate({
      inputRange: [0, 0.5, 1],
      outputRange: [0, 50, 0]
    })
    let date = new Date(rowData.createdOn)
    let source = noImageIcon
    if (rowData.imageUrl) {
      source = { uri: rowData.imageUrl }
    }
    date = date.toUTCString()
    date = date.split(' ').slice(0, 4).join(' ')
    let currentDate = new Date()
    currentDate = currentDate.toUTCString()
    currentDate = currentDate.split(' ').slice(0, 4).join(' ')
    if (rowID == 0) {
      const thought = rowData.thought
      const story = rowData.story
      if (thought) {
        statusText = 'Thought of the day'
      } else if (story) {
        statusText = 'Story of the day'
      }
      return (
        <View>
          <TouchableOpacity
            onPress={() => {
              const { dispatch } = this.props
              const contentDate = new Date(rowData.createdOn)
              dispatch(dateChange(contentDate))
              GoogleAnalytics.trackEvent('recordView', '' + rowData.title + '')
              Actions.contentscreen({titleId: rowData.tId})
            }}>
              <Text style={[styles.textColor, styles.date]}>{date}</Text>
            <View style={{backgroundColor: this.props.button, height:25}}>
              <Text
                style={{
                  color: Colors.white,
                  fontStyle: 'italic',
                  alignSelf: 'center',
                  fontSize: 16,
                }}
              >{statusText}</Text>
            </View>
            <View 
              style={[
                styles.listItem,
                  { height: 140, backgroundColor: this.props.footer }
                ]
              }>                                 
              <Image
                source={source}
                style={[styles.contentPic, {borderColor: this.props.navBar, marginTop: 30}]}
              />
              <View style={styles.listContent}>
                <Animated.Text numberOfLines={1} style={[styles.textColor, { marginBottom: 10, marginLeft: introButton }]}>{rowData.title}</Animated.Text>
                <Text
                  numberOfLines={3}
                  style={{ lineHeight: 25, fontFamily: Platform.OS == 'ios' ? 'helvetica neue' : 'roboto', fontSize: 14}}
                >
                  {rowData.thought ? rowData.thought : rowData.story}
                </Text>
              </View>
            </View>
          </TouchableOpacity>
          {recordLength > 1 ? 
          <View style={{height: 25, backgroundColor: Colors.moreStory}}>
            <Text
              style={{
                color: Colors.white,
                fontStyle: 'italic',
                alignSelf: 'center',
                fontSize: 16,
              }}
            >More Stories</Text>
          </View> : null }
        </View>
      )
    } else {
      return (
        <View style={{
          flex: 1,
          paddingHorizontal: 10,
          paddingVertical: 5,
        }}>
          <TouchableOpacity               
            onPress={() => {
              const { dispatch } = this.props
              let contentDate = new Date(rowData.createdOn)
              dispatch(dateChange(contentDate))
              GoogleAnalytics.trackEvent('recordView', '' + rowData.title + '')
              Actions.contentscreen({titleId: rowData.tId})
            }}
          >
            <View style={{flexDirection: 'row', flexWrap: 'wrap'}}>
              <Image
                source={source}
                style={[styles.contentPic, {borderColor: this.props.navBar}]}
              />
              <View style={styles.listContent}>            
                <View style={[styles.spaceContainer, { marginBottom: 10, flex: 1 }]}>
                  <View style={{flex: 0.5}}>
                  <Text style={styles.textColor} numberOfLines={1} >{rowData.title}</Text>
                  </View>
                  <View style={{flex: 0.4}}>
                  <Text style={[styles.textColor, { fontSize: 12, alignSelf: 'flex-end', marginLeft: 5 }]}>{date}</Text>
                  </View>
                </View>
                <Text numberOfLines={1} style={{ lineHeight: 25, fontFamily: Platform.OS == 'ios' ? 'helvetica neue' : 'roboto', fontSize: 14 }}>
                  {rowData.thought ? rowData.thought : rowData.story}
                </Text>        
              </View>
            </View>
          </TouchableOpacity>
        </View>
      )
    }
  }

  onSearchClick = () => {
    this.setState({ search: true })
    setTimeout(() => {
      this.refs.tag.focus()
    }, 50)   
  }

  render() {    
    if (this.props.success) {      
      return (      
        <View style={[styles.container, { backgroundColor: this.props.container, paddingHorizontal: 0, paddingTop: 0, paddingBottom: 0 }]}>
          <StatusBar
            backgroundColor={this.props.statusBar}
            barStyle="light-content"
          />
          { this.state.search ?           
          <View style={[styles.homeNavBar, styles.spaceContainer, { backgroundColor: Colors.white, paddingTop: Platform.OS === 'ios' ? 20 : 5, marginBottom: 10 }]}>
            <View style={[styles.spaceAround, {flex: 1}]}>
              <TouchableOpacity style={{ padding: 10, flex: 0.1 }} onPress={() => {
                this.setState({ tag: '', search: false, isRecords: true })             
                dismissKeyboard()
                const { dispatch } = this.props
                dispatch(records(this.state.rows))
              }}>
                <Icon name="arrow-left" color={this.props.navBar} size={20} />
              </TouchableOpacity>
              <TextInput
                ref="tag"
                style={{ flex: 0.9, fontSize: 16, marginBottom: 6 }}
                onChangeText={this.onChangeTag}
                underlineColorAndroid ="transparent"
                placeholder="Search Records.."
                value={this.state.tag}
                maxLength={25}
              />
            </View>
            <TouchableOpacity onPress={this.search} style={{ padding: 10, marginBottom: 6 }}>
              <Icon name="search" color={this.props.navBar} size={20} />
            </TouchableOpacity>
          </View> :
          <View style={[styles.homeNavBar, styles.spaceContainer, { backgroundColor: this.props.navBar, paddingTop: Platform.OS === 'ios' ? 20 : 5, marginBottom: 10 }]}>
            <TouchableOpacity onPress={() => {
              this.props.openMenu()              
            }} style={{ paddingVertical:10, paddingLeft: 10, paddingRight: 40 }}>
              <Icon name="bars" color={Colors.white} size={20} />
            </TouchableOpacity>
            <Text style={[styles.homeTitle,{paddingLeft: 35}]}>Home</Text>
            <View style={{flexDirection: 'row', justifyContent: 'space-around'}}>
            <TouchableOpacity onPress={() => this.props.dispatch(isCalendar(true))} style={{ paddingVertical:10, paddingLeft: 40, paddingRight: 10 }}>
              <Icon name="calendar" color={Colors.white} size={20} />
            </TouchableOpacity>
            <TouchableOpacity onPress={this.onSearchClick} style={{ paddingVertical:10, paddingLeft: 20, paddingRight: 10 }}>
              <Icon name="search" color={Colors.white} size={20} />
            </TouchableOpacity>
            </View>
          </View>
        }
          { this.state.isRecords ?
            <ListView
              ref="listview"
              enableEmptySections={true}
              dataSource={ds.cloneWithRows(this.getListViewData())}
              onScroll={this.getNextRecords}
              onEndReachedThreshold={2000}
              automaticallyAdjustContentInsets={false}             
              renderRow={this.renderRowElement}
              renderFooter={() => {
                return(
                  <View>
                    {this.state.recordsExist && !this.state.search ?
                    <View style={{ height: 40, justifyContent: 'center', alignItems: 'center'}}>
                      <Text style={[styles.textColor, {alignSelf: 'center'}]}>Loading...</Text>
                    </View>:null}
                  </View>
                )
              }}
              renderSeparator={(sectionID, rowID, adjacentRowHighlighted) => {
                if(rowID == 0) {
                  return null
                } else  {
                return(
                  <View
                    style={{
                      height: 1,
                      backgroundColor: this.props.footer,
                      marginLeft: 60,
                    }}
                  />
                )
              }
              }}
            /> :
            <View style={[styles.container, {backgroundColor: this.props.container}]}>
              <Text style={[styles.textColor, { alignSelf: 'center' }]}>No Data Found</Text>
            </View> }

        </View>
      )
    } else {
      return (
        <View style={[styles.container, {backgroundColor: this.props.container}]}>
          <StatusBar
            backgroundColor={this.props.statusBar}
            barStyle="light-content"
          />
          <Spinner visible={true} color={this.props.navBar} overlayColor={'transparent'} />          
        </View>
      )
    }
  }
}

HomeScreen.propTypes = {
  dispatch: PropTypes.func,
  statusBar: PropTypes.string,
  navBar: PropTypes.string,
  button: PropTypes.string,
  container: PropTypes.string,
  tabcontent: PropTypes.string,
  titleCarousel: PropTypes.string,
  footer: PropTypes.string,
  notify: PropTypes.bool,
  success: PropTypes.bool,
  date: PropTypes.string,
  notify: PropTypes.bool,

}

function mapStateToProps(state) {
  return {
    success: state.ValEdu.get('success'),
    rows: state.ValEdu.get('rows'),
    date: state.ValEdu.get('date'),
    isFooter: state.ValEdu.get('isFooter'),
    statusBar: state.ValEdu.get('statusBar'),
    navBar: state.ValEdu.get('navBar'),
    button: state.ValEdu.get('button'),
    container: state.ValEdu.get('container'),
    tabcontent: state.ValEdu.get('tabcontent'),
    titleCarousel: state.ValEdu.get('titleCarousel'),
    footer: state.ValEdu.get('footer'),
    notify: state.ValEdu.get('notify'),
    isChannelChanged: state.ValEdu.get('isChannelChanged'),
  }
}

export default connect(mapStateToProps)(HomeScreen)
